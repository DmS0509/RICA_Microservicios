package com.rica.api.investigadores_service.investigadores.infraestructura.salida.mensajeria;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.rica.api.investigadores_service.investigadores.aplicacion.PublicadorEventos;

import tools.jackson.databind.ObjectMapper;

@Component
public class OutboxPublicadorEventos implements PublicadorEventos {

    private final OutboxEventRepository repositorio;
    private final ObjectMapper objectMapper;

    public OutboxPublicadorEventos(OutboxEventRepository repositorio, ObjectMapper objectMapper) {
        this.repositorio = repositorio;
        this.objectMapper = objectMapper;
    }

    @Override
    public void publicar(String topico, String clave, Map<String, Object> contenido) {
        String payload = objectMapper.writeValueAsString(contenido);
        repositorio.save(new OutboxEvent(topico, clave, payload));
    }
}
